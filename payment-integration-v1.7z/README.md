# payment-integration

## before usage

rename .env.example to .env and replace keys with the apprapriate key.

use the env_util.php to keep the secret key secret.

implement a better .env utilizer if needed

add .env to .gitignore